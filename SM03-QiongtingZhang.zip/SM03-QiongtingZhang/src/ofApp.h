#pragma once

#include "ofMain.h"
#include "ofxCv.h"
#include "ofxGui.h"
#include "ofxKinect.h"

class ofApp : public ofBaseApp{
    
public:
    void setup();
    void update();
    void draw();
    void mouseReleased(int x, int y, int button);
    
    ofxKinect kinect;
    ofImage thresholdImg1, thresholdImg2, thresholdImg3;
    ofParameter<float> step;
    
    
    //    vector<ofImage> thresholdImgs;
    
    int i;
    
    ofParameter<float> nearThreshold1;
    ofParameter<float> farThreshold1;
    
    ofParameter<float> nearThreshold2;
    ofParameter<float> farThreshold2;
    ofParameter<float> nearThreshold3;
    ofParameter<float> farThreshold3;
    
    ofxPanel guiPanel;
    float distAtMouse;
    int depthAtMouse;
    ofColor Col1, Col2, Col3;
    
    ofxCv::ContourFinder contourFinder;
    ofPolyline poly;
    ofParameter<float> minArea, maxArea, threshold;
    ofParameter<bool> holes;
    ofParameter<int> lineWidth;
    //    vector <ofColor> Colors;
};
