#include "ofApp.h"
using namespace ofxCv;
using namespace cv;

//--------------------------------------------------------------
void ofApp::setup(){
    ofSetWindowShape(640, 480);
    
    // Start the depth sensor.
    kinect.setRegistration(true);
    kinect.init();
    kinect.open();
    
    // Setup the parameters.
    nearThreshold1.set("Near Threshold1", 0.0f, 0.0f, 0.1f);
    farThreshold1.set("Far Threshold1", 0.03f, 0.0f, 0.1f);
    
    nearThreshold2.set("Near Threshold2", 0.02f, 0.0f, 0.1f);
    farThreshold2.set("Far Threshold2", 0.06f, 0.0f, 0.1f);
    
    nearThreshold3.set("Near Threshold3", 0.01f, 0.0f, 0.1f);
    farThreshold3.set("Far Threshold3", 0.02f, 0.0f, 0.1f);
    
    // Setup the gui.
    guiPanel.setup("Depth Threshold", "settings.json");
    guiPanel.add(nearThreshold1);
    guiPanel.add(farThreshold1);
    guiPanel.add(nearThreshold2);
    guiPanel.add(farThreshold2);
    
    guiPanel.add(nearThreshold3);
    guiPanel.add(farThreshold3);
    
    //    guiPanel.add(minArea.set("Min area", 4, 1, 100));
    //    guiPanel.add(maxArea.set("Max area", 330, 1, 500));
    guiPanel.add(threshold.set("Contour Threshold", 110, 0, 255));
    //    guiPanel.add(lineWidth.set("Line Width", 4, 1,6));
    //    guiPanel.add(holes.set("Holes", true));
    
    Col1=ofColor((int) ofRandom(0,255), (int) ofRandom(0,255), 50, 100);
    Col2=ofColor((int) ofRandom(0,255), (int) ofRandom(0,255), 50, 100);
    Col3=ofColor((int) ofRandom(0,255), (int) ofRandom(0,255), 50, 100);
}

//--------------------------------------------------------------
void ofApp::update(){
    kinect.update();
    if (kinect.isFrameNew())
    {
        contourFinder.setMinAreaRadius(4);
        contourFinder.setMaxAreaRadius(330);
        contourFinder.setThreshold(threshold);
        contourFinder.findContours(kinect);
        contourFinder.setFindHoles(true);
        
        ofFloatPixels rawDepthPix = kinect.getRawDepthPixels();
        ofFloatPixels thresholdNear, thresholdFar, thresholdResult;
        ofxCv::threshold(rawDepthPix, thresholdNear, nearThreshold1);
        ofxCv::threshold(rawDepthPix, thresholdFar, farThreshold1, true);
        ofxCv::bitwise_and(thresholdNear, thresholdFar, thresholdResult);
        thresholdImg1.setFromPixels(thresholdResult);
        
        
        ofxCv::threshold(rawDepthPix, thresholdNear, nearThreshold2);
        ofxCv::threshold(rawDepthPix, thresholdFar, farThreshold2, true);
        ofxCv::bitwise_and(thresholdNear, thresholdFar, thresholdResult);
        thresholdImg2.setFromPixels(thresholdResult);
        
        ofxCv::threshold(rawDepthPix, thresholdNear, nearThreshold3);
        ofxCv::threshold(rawDepthPix, thresholdFar, farThreshold3, true);
        ofxCv::bitwise_and(thresholdNear, thresholdFar, thresholdResult);
        thresholdImg3.setFromPixels(thresholdResult);
        
//I tried to use image array to generate multiple thresholdImg, but not work, so I just manually did it. I do not know why was it.
        //        i=0;
        //        for (float nearThreshold=0.0;nearThreshold <= 0.1-step+0.0001;nearThreshold+=step){
        //            float farThreshold=nearThreshold+step;
        //            if (farThreshold>0.1){farThreshold=0.1;}
        //            ofFloatPixels rawDepthPix = kinect.getRawDepthPixels();
        //            ofFloatPixels thresholdNear, thresholdFar, thresholdResult;
        //            ofxCv::threshold(rawDepthPix, thresholdNear, nearThreshold);
        //            ofxCv::threshold(rawDepthPix, thresholdFar, farThreshold, true);
        //            ofxCv::bitwise_and(thresholdNear, thresholdFar, thresholdResult);
        //            thresholdImg.setFromPixels(thresholdResult);
        //            thresholdImgs.push_back(thresholdImg);
        //            i++;
        //        }
    }
}

//--------------------------------------------------------------
void ofApp::draw(){

    //    kinect.getDepthTexture().draw(0, 0);
    
    ofPushStyle();
    ofSetColor(Col1);
    thresholdImg1.draw(0, 0);
    ofPopStyle();
    
    ofPushStyle();
    ofSetColor(Col2);
    thresholdImg2.draw(0, 0);
    ofPopStyle();
    
    ofPushStyle();
    ofSetColor(Col3);
    thresholdImg3.draw(0, 0);
    ofPopStyle();
    
    
    for(int i =0; i<contourFinder.size();i++){
        ofPoint center = toOf(contourFinder.getCenter(i));
        float dist = kinect.getDistanceAt(center[0], center[1]);
        ofPushStyle();
        ofColor targetColor;
        ofSetLineWidth(dist/100);
        targetColor = kinect.getPixels().getColor(center[0],center[1]);
        
        contourFinder.setTargetColor(targetColor);
        
        ofSetColor(targetColor);
        contourFinder.getPolyline(i).draw();
        ofPopStyle();
    }
    
    guiPanel.draw();
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    Col1=ofColor((int) ofRandom(0,255), (int) ofRandom(0,255), 50, 100);
    Col2=ofColor((int) ofRandom(0,255), (int) ofRandom(0,255), 50, 100);
    Col3=ofColor((int) ofRandom(0,255), (int) ofRandom(0,255), 50, 100);
}

