

#include "ofApp.h"

using namespace ofxCv;
using namespace cv;

void ofApp::setup() {
    ofSetVerticalSync(true);
    ofBackground(0, 0, 0);
    cameraIsOn=true;
    vid.load("night.mp4");
    vid.setLoopState(OF_LOOP_NORMAL);
    vid.play();
    cam.setup(ofGetWidth(), ofGetHeight());
    gui.setup();
    gui.add(minArea.set("Min area", 4, 1, 100));
    gui.add(maxArea.set("Max area", 330, 1, 500));
    gui.add(threshold.set("Threshold", 26, 0, 255));
    gui.add(lineWidth.set("Line Width", 4, 1,6));
    gui.add(holes.set("Holes", true));
    gui.add(changeToVid.set("Video",false));
}

void ofApp::update() {
    if (cameraIsOn && !changeToVid){
        cam.update();
        if(cam.isFrameNew()) {
            contourFinder.setMinAreaRadius(minArea);
            contourFinder.setMaxAreaRadius(maxArea);
            contourFinder.setThreshold(threshold);
            contourFinder.findContours(cam);
            contourFinder.setFindHoles(holes);
        }
    }
    if (changeToVid){
        vid.update();
        if(vid.isFrameNew()) {
            contourFinder.setMinAreaRadius(minArea);
            contourFinder.setMaxAreaRadius(maxArea);
            contourFinder.setThreshold(threshold);
            contourFinder.findContours(vid);
            contourFinder.setFindHoles(holes);
    }
    }
    
    
}
    
    void ofApp::draw() {
//            cam.draw(0, 0);
        ofSetLineWidth(lineWidth);
        
        
        for(int i =0; i<contourFinder.size();i++){
            ofPoint center = toOf(contourFinder.getCenter(i));
            ofPushStyle();
            ofColor targetColor;
            if(!changeToVid){
            targetColor = cam.getPixels().getColor(center[0],center[1]);
            }
            else {
            targetColor = vid.getPixels().getColor(center[0],center[1]);
                
            }
            contourFinder.setTargetColor(targetColor);
            
            ofSetColor(targetColor);
            contourFinder.getPolyline(i).draw();
            ofPopStyle();
        }
        
        gui.draw();
    }
    
    
    
    
    //--------------------------------------------------------------
    void ofApp::keyPressed(int key){
        if (key=='s'){
            cameraIsOn=!cameraIsOn;
        }
    }
    
    //--------------------------------------------------------------
    void ofApp::keyReleased(int key){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::mouseMoved(int x, int y ){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::mouseDragged(int x, int y, int button){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::mousePressed(int x, int y, int button){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::mouseReleased(int x, int y, int button){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::mouseEntered(int x, int y){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::mouseExited(int x, int y){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::windowResized(int w, int h){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::gotMessage(ofMessage msg){
        
    }
    
    //--------------------------------------------------------------
    void ofApp::dragEvent(ofDragInfo dragInfo){
        
    }
